# -*- coding: utf-8 -*-
import re
import sys
import os
import time
import urllib
import urllib2
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


__addon_id__= 'plugin.video.nova.play'
__Addon = xbmcaddon.Addon(__addon_id__)
searchicon = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")

MUA = 'Mozilla/5.0 (Linux; Android 4.2.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:36.0) Gecko/20100101 Firefox/36.0'
thumbsize = '200x150'

def CATEGORIES():
        addDir('Търсене на предаване','http://play.novatv.bg/tursene?term=',2,searchicon)
        #TV programa & cover
        api = "http://novatv.bg/schedule/listview";
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', UA)]
        data = opener.open(api).read()
        
        match = re.compile('(.+?) </span></div>.*\n.*\n.*<img src="(.+?)"').findall(data)
        title = match[0][0].replace('         ', '')
        title = 'В момента по NOVA:' + title
        #print title
        #print 'Обложка:' + match[0][1]
        addLink(title,'rtmp://edge1.evolink.net:2010/fls/_definst_/ntv_2.stream pageUrl=http://i.cdn.bg/live/0OmMKJ4SgY token=N0v4TV6#2 timeout=12',0,5,match[0][1])
        
        
        #Spisak s kategorii
        api = "http://play.novatv.bg/programi";
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', UA)]
        data = opener.open(api).read()
        
        match = re.compile('href="(.+?)"\n.*\n.*\n.*\n.*\n.*\n.*\n.*clip-title-new">(.+?)<.*\n.*\n.*\n.*\n.*src="(.+?)"').findall(data)
        for url,name,thumbnail in match:
            thumbnail=thumbnail.replace('{size}',thumbsize)
            thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i2.wp.com/cdn.playapi.mtgx.tv')
            addDir(name,url,1,thumbnail)

        
        #addDir('Детски','http://play.novatv.bg/kategorii/detski',1,'https://lh3.ggpht.com/Ln242QZU_geIlLPUtqlDyWDwpjM7QCXK0NVLYnXQLLuMSOCh0S8rzhXb6FadP3Wk6JHIIw=s126')
        #addDir('','',1,'')



#Spisak na prevaniqta v edna kategoria
def INDEXCAT(url):
        href = url
        req = urllib2.Request(href)
        req.add_header('User-Agent', MUA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
           
        match = re.compile('href="(.+?)".*\n.*\n.*\n.*\n.*\n.*lazyload".*data-src="(.+?)".*\n.*\n.*\n.*\n.*class="clip-title">(.+?)<').findall(data)
        for adres,thumbnail,title in match:
            thumbnail=thumbnail.replace('{size}',thumbsize)
            thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i1.wp.com/cdn.playapi.mtgx.tv')
            addDir(title,adres,6,thumbnail)


#Izvlichane ID na konkretno predavane
def INDEXSHOW(url):
    href = url
    req = urllib2.Request(href)
    req.add_header('User-Agent', MUA)
    response = urllib2.urlopen(req)
    data=response.read()
    response.close()

    match = re.compile('epizodi.id=(.+?)"').findall(data)
    for showid in match:
        print 'showid=' + str(showid)
        INDEXPAGES(showid)



#Razlistvane epizodite na konkretno predavane
def INDEXPAGES(showid):
        api = 'http://playapi.mtgx.tv/v3/videos?season=' + showid
        req = urllib2.Request(api)
        req.add_header('User-Agent', MUA)
        response = urllib2.urlopen(req)
        print 'request page url:' + api
        data=response.read()
        response.close()

        match = re.compile('id":(.+?),".+?"subject":"(.+?)".+?is_episodic":(.+?),(.+?)},"duration":(.+?),.+?image":{"href":"(.+?)"').findall(data)
        for vid,title,serial,epizod,duration,thumbnail in match:
            thumbnail = thumbnail.replace("\/", "/")
            thumbnail=thumbnail.replace('{size}',thumbsize)
            thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i0.wp.com/cdn.playapi.mtgx.tv')
            #print thumbnail
            title = title.decode('unicode_escape', errors='ignore').encode('utf-8', errors='ignore')
            title = title.replace('\/', '/')
            if serial == 'true':
                matchs = re.compile('season":(.+?),"episode":"(.+?)"').findall(epizod)
                for season,episode in matchs:
                    title = title + ' - сезон ' + str(season) + ' епизод ' + str(episode)
            #print title
            addLink(title,vid,duration,4,thumbnail)
        
        #If results are on more pages
        lisearch = re.compile('next.*season=(.+?)"').findall(data)
        for page in lisearch:
            print 'There is next page:' + page
            thumbnail='DefaultFolder.png'
            addDir('следваща страница>>',page,3,thumbnail)


#Izvlichane na stream i puskane
def VIDEOLINKS(name,url,iconimage):
        Image = iconimage
        api = 'http://playapi.mtgx.tv/v3/videos/stream/' + url
        headers = {'User-Agent': MUA}
        r = requests.get(api, headers=headers)
        #print r.url
        data = str(r.text)
        
        #Select by available quality
        try:
            playurl = re.compile('hls":"(.+?)"').findall(data)
            playurl = str(playurl[0])
            playurl = playurl.replace('\/', '/')
            playurl = playurl.replace('_m.mp4', '.mp4')
            print 'choosed HLS link:' + playurl
            
        except IndexError: 
            playurl = re.compile('medium":"(.+?)"').findall(data)
            playurl = str(playurl[0])
            playurl = playurl.replace('\/', '/')
            if 'rtmp' in playurl:
                playurl = playurl.replace('rtmp://stream.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
                playurl = playurl.replace('rtmp://streambg.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
            print 'choosed medium link:' + playurl

        
        #Play Selected Item
        li = xbmcgui.ListItem(iconImage=Image, thumbnailImage=Image, path=playurl)
        li.setInfo('video', { 'title': name })
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = playurl))
        except:
            xbmc.executebuiltin("Notification('Грешка','Видеото липсва на сървъра!')")


#Playvane na online stream prez addon
def STREAMPLAY(url):
        #TV programa & cover
        api = "http://novatv.bg/schedule/listview";
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', UA)]
        data = opener.open(api).read()
        
        match = re.compile('(.+?) </span></div>.*\n.*\n.*<img src="(.+?)"').findall(data)
        title = match[0][0].replace('         ', '')
        title = 'В момента по NOVA:' + title
        #print title
        #print 'Обложка:' + match[0][1]
        li = xbmcgui.ListItem(iconImage=match[0][1], thumbnailImage=match[0][1], path=url)
        li.setInfo('video', { 'title': title })
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=url))


#Tursene na predavane
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Търсачка на предавания')
        keyb.doModal()
        searchText = ''
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            searchText=searchText.replace(' ','+')
            url= url + searchText
            url = url.encode('utf-8')
            print 'SEARCHING:' + url
            INDEXCAT(url.lower())
        else:
            addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")


def addLink(name,url,duration,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.addStreamInfo("Video", { "duration": duration })
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok



def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass



if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
    
elif mode==1:
        print ""+url
        INDEXCAT(url)

elif mode==2:
        print ""+url
        SEARCH(url)

elif mode==3:
        print ""+url
        INDEXPAGES(url)
        
elif mode==4:
        print ""+url
        VIDEOLINKS(name,url,iconimage)

elif mode==5:
        print ""+url
        STREAMPLAY(url)
        
elif mode==6:
        print ""+url
        INDEXSHOW(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
